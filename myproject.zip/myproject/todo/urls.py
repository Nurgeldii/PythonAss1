from django.urls import path
from .views import TodoCreate, TodoList, TodoDetail, TodoUpdate, TodoDelete, LoginView, RegisterPage
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('', TodoList.as_view(), name='todo'),
    path('todo-create/', TodoCreate.as_view(), name='todo-create'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    path('register/', RegisterPage.as_view(), name='register'),

    path('todo/<int:pk>/', TodoDetail.as_view(), name='todo-detail'),
    path('todo-update/<int:pk>/', TodoUpdate.as_view(), name='todo-update'),
    path('todo-delete/<int:pk>/', TodoDelete.as_view(), name='todo-delete')

]
